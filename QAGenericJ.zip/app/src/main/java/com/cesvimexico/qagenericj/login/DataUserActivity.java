package com.cesvimexico.qagenericj.login;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.cesvimexico.qagenericj.R;

public class DataUserActivity extends AppCompatActivity {

    private SharedPreferences preferences;
    private String user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_user);

        preferences = PreferenceManager.getDefaultSharedPreferences(this);
        preferences = getSharedPreferences("usrdata", Context.MODE_PRIVATE);
        user = preferences.getString("email", "");

        TextView txtAuditorDatos = findViewById(R.id.txtUser);
        Button btnCerrarDatos = findViewById(R.id.btnCerrarDatos);

        txtAuditorDatos.setText(user.toString());
        btnCerrarDatos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                finish();

            }
        });
    }
}