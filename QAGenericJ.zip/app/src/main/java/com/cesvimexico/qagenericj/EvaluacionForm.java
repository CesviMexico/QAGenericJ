package com.cesvimexico.qagenericj;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.cesvimexico.qagenericj.Camera.CameraActivity;
import com.cesvimexico.qagenericj.adapters.AdapterCamp;
import com.cesvimexico.qagenericj.db.DBManager;
import com.cesvimexico.qagenericj.model.Campo;
import com.cesvimexico.qagenericj.model.EvaluacionData;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

public class EvaluacionForm extends AppCompatActivity {

    private int id_servicio;
    private String idE;
    private String sql;
    private String email;
    private RecyclerView recyclerViewForm;
    private FloatingActionButton buttonGuardarServ;
    private SharedPreferences preferences;
    private Cursor cursor;
    private DBManager bdm;
    private SQLiteDatabase db;
    private FirebaseFirestore dbFB;
    private String TAG = "EVALUACION";

    private int id_evaluacion;
    private FloatingActionButton btn_tk_photo_cia;
    private String nombrePic;

    private Uri photoURI;
    private File photoFile;
    private Bitmap bm;

    private ImageView imageFront;

    private FirebaseStorage storage;
    private StorageReference storageRef;
    private int id_area;

    private boolean nueva = false;
    private String front_pic;
    private String nombrePicPrincipal;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_evaluacion_form);


        recyclerViewForm = findViewById(R.id.recyclerViewForm);
        buttonGuardarServ = findViewById(R.id.buttonGuardarServ);
        btn_tk_photo_cia = findViewById(R.id.btn_tk_photo_eva);
        imageFront = findViewById(R.id.imageFront);


        preferences = PreferenceManager.getDefaultSharedPreferences(this);
        preferences = getSharedPreferences("usrdata", Context.MODE_PRIVATE);
        email = preferences.getString("email", "");
        this.id_servicio = getIntent().getExtras().getInt("id_servicio");
        this.id_area = getIntent().getExtras().getInt("id_area");
        this.idE = getIntent().getExtras().getString("idE");

        EvaluacionData evalData = new EvaluacionData(EvaluacionForm.this, idE);

        dbFB = FirebaseFirestore.getInstance();
        storage = FirebaseStorage.getInstance();
        storageRef = storage.getReference();

        bdm = new DBManager(EvaluacionForm.this);
        db = bdm.getWritableDatabase();

        if (savedInstanceState != null) {
            idE = savedInstanceState.getString("idE");
            nombrePic = savedInstanceState.getString("nombrePic");
            if (nombrePic != null) {
                bm = showAndScale();
                imageFront.setImageBitmap(bm);
            }
        }

//        if (evalData.getId_evaluacion() != 0) {
//            imageFront.setVisibility(View.GONE);
//            btn_tk_photo_cia.setVisibility(View.GONE);
//        }


        sql = "SELECT pic AS total FROM `qa_zeval` WHERE id_evaluacion_fb= '" + idE + "'";
        cursor = db.rawQuery(sql, null);
        if (cursor.getCount() > 0) {
            while (cursor.moveToNext()) {
                front_pic = cursor.getString(0);
            }
        }


        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM-yyyy HH:mm", Locale.getDefault());
        Date date = new Date();
        String fecha = dateFormat.format(date);

        if (front_pic != null) {
            storageRef.child("images/" + front_pic).
                    getDownloadUrl().
                    addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {
                            String imageURL = uri.toString();

                            Glide.with(EvaluacionForm.this)
                                    .asBitmap()
                                    .load(imageURL)
                                    .timeout(10000)
                                    .centerCrop()
                                    .override(300, 300)
                                    .listener(new RequestListener<Bitmap>() {
                                                  @Override
                                                  public boolean onLoadFailed(@Nullable GlideException e, Object o, Target<Bitmap> target, boolean b) {
                                                      return false;
                                                  }

                                                  @Override
                                                  public boolean onResourceReady(Bitmap bitmap, Object o, Target<Bitmap> target, DataSource dataSource, boolean b) {
                                                      //String path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS) + "/audits/" + model.getId() + "/" + model.getPic();
                                                      File file = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), front_pic);
                                                      try {
                                                          file.createNewFile();
                                                          FileOutputStream ostream = new FileOutputStream(file);
                                                          bitmap.compress(Bitmap.CompressFormat.JPEG, 100, ostream);
                                                          ostream.close();
                                                      } catch (Exception e) {
                                                          e.printStackTrace();
                                                      }
                                                      return false;
                                                  }
                                              }
                                    )
                                    .into(imageFront);
                        }
                    }).

                    addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception exception) {
                            // Handle any errors
                            //Log.d("ERROR_AUDIT", exception.getMessage());
                        }
                    });
        }

        // Create a reference with an initial file path and name
        //StorageReference pathReference = storageRef.child("images/"+model.getPic());

//                    Glide.with(EvaluacionList.this /* context */)
//                            .load(pathReference)
//                            .into(holder.imgFrontLE);


        cursor = db.rawQuery(
                "SELECT id_evaluacion_fb FROM qa_zeval WHERE id_evaluacion_fb = " + idE,
                null);

        if (cursor.getCount() == 0) {
            sql = "INSERT INTO qa_zeval(id_evaluacion_fb, id_usuario, id_servicio, f_creada ) VALUES ('" + idE + "','" + email + "','" + id_servicio + "','" + fecha + "' )";
            db.execSQL(sql);
            evalData = new EvaluacionData(EvaluacionForm.this, idE);
            nueva = true;
        }

        id_evaluacion = evalData.getId_evaluacion();


        ArrayList<Campo> result = new ArrayList<>();

        cursor = db.rawQuery(
                "SELECT id_campo,id_servicio,categoria,tipo,etiqueta,mostrar,status,long,orden,   `qa_zeval_det`.`valor_numerico`,  `qa_zeval_det`.`valor_fecha`,  `qa_zeval_det`.`valor_cadena`  FROM qa_camp LEFT OUTER JOIN `qa_zeval_det` ON (`qa_camp`.`id_campo` = `qa_zeval_det`.`id_campo`) and (`qa_zeval_det`.`id_evaluacion` = "+id_evaluacion+") WHERE id_servicio = " + id_servicio + " AND status='ALTA' AND tipo<>'CANVAS' ",
                null);
        while (cursor.moveToNext()) {
            result.add(
                    new Campo(cursor.getInt(0),
                            cursor.getInt(1),
                            cursor.getString(2),
                            cursor.getString(3),
                            cursor.getString(4),
                            cursor.getInt(5),
                            cursor.getString(6),
                            cursor.getInt(7),
                            cursor.getInt(8),
                            cursor.getString(9),
                            cursor.getString(10),
                            cursor.getString(11)
                    ));
        }
        AdapterCamp adaptador = new AdapterCamp(EvaluacionForm.this, result, idE, id_evaluacion);

        recyclerViewForm.setHasFixedSize(true);
        recyclerViewForm.setLayoutManager(new LinearLayoutManager(EvaluacionForm.this, LinearLayoutManager.VERTICAL, false));
        //recyclerViewForm.setLayoutManager(new GridLayoutManager(this, 1, GridLayoutManager.VERTICAL, false));
        recyclerViewForm.setAdapter(adaptador);


        buttonGuardarServ.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Map<String, Object> servicio = new HashMap<>();
                String estado = "", municipio = "", lugar = "";


                cursor = db.rawQuery(
                        "SELECT nom_campo_bd, tipo, valor_cadena, valor_fecha, valor_numerico\n" +
                                "FROM\n" +
                                "  `qa_zeval`\n" +
                                "  INNER JOIN `qa_zeval_det` ON (`qa_zeval`.`id_evaluacion` = `qa_zeval_det`.`id_evaluacion`)\n" +
                                "  INNER JOIN `qa_camp` ON (`qa_zeval`.`id_servicio` = `qa_camp`.`id_servicio`)\n" +
                                "  AND (`qa_camp`.`id_campo` = `qa_zeval_det`.`id_campo`) AND `nom_campo_bd` IS NOT NULL\n" +
                                "WHERE\n" +
                                "  `qa_zeval`.`id_evaluacion_fb` = '" + idE + "'",
                        null);
                while (cursor.moveToNext()) {
                    switch (cursor.getString(1)) {
                        case "DATETIME":
                        case "DATE":
                            servicio.put(cursor.getString(0), cursor.getString(3));
                            break;
                        case "TEXT":
                        case "SELECT":
                            if (cursor.getString(0).equals("estado")) {
                                estado = cursor.getString(2);
                            } else if (cursor.getString(0).equals("municipio")) {
                                municipio = cursor.getString(2);
                            } else {
                                servicio.put(cursor.getString(0), cursor.getString(2));
                            }
                            break;
                        case "NUMB":
                            servicio.put(cursor.getString(0), cursor.getString(4));
                            break;
                    }
                }
                lugar = String.join(", ", estado, municipio);
                servicio.put("lugar", lugar);

                servicio.put("idE", idE);

                if (nueva) {
                    servicio.put("status", "CREADO");
                    servicio.put("f_crea", fecha);
                    servicio.put("avance", 0);
                }
                servicio.put("id_usuario", email);
                servicio.put("id_servicio", id_servicio);
                servicio.put("id_evaluacion", id_evaluacion);

                if (nombrePic != null) {
                    storageRef = storage.getReference();
                    StorageReference imgFront = storageRef.child("images/" + nombrePic);

                    Uri uri = Uri.fromFile(new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), nombrePic));
                    UploadTask uploadTask = imgFront.putFile(uri);
                    uploadTask.addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception exception) {
                            // Handle unsuccessful uploads
                        }
                    }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {


                            StorageReference file = storageRef.child("images/" + nombrePicPrincipal);
                            file.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    //Toast.makeText(getApplicationContext(), "Se ha actualizado la fotografía", Toast.LENGTH_LONG).show();
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception exception) {
                                    //Toast.makeText(getApplicationContext(), "Error al intentar actualizar la fotografía", Toast.LENGTH_LONG).show();
                                }
                            });

                            //sql = "UPDATE qa_zeval SET pic='" + nombrePic + "' WHERE id_evaluacion_fb='" + idE + "'";
                            //db.execSQL(sql);


                            // taskSnapshot.getMetadata() contains file metadata such as size, content-type, etc.
                            // ...
                        }
                    });
                    servicio.put("pic", nombrePic);
                }
                dbFB.collection("servicio").document(idE).set(servicio, SetOptions.merge());
/*
AGREGAR UN ONFOCUS PARA QUE GUARDE EL DATO AL DAR CLIC EN EL BOTON
 */


                openActivity();

            }
        });


        btn_tk_photo_cia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    photoFile = createImageFile();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                enableCamera();
                /*
                Intent takePictureIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);

                if (takePictureIntent.resolveActivity(EvaluacionForm.this.getPackageManager()) != null) {
                    // Crea el File
                    photoFile = null;
                    try {
                        photoFile = createImageFile();
                    } catch (IOException ex) {
                        // Error cuando se creo el archivo
                        String error = ex.toString();
                    }
                    if (photoFile != null) {
                        photoURI = FileProvider.getUriForFile(Objects.requireNonNull(getApplicationContext()),
                                BuildConfig.APPLICATION_ID + ".provider",
                                photoFile);
                        takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                        startActivityForResult(takePictureIntent, 7);
                    }
                }

                 */
            }

        });
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == 2){

            Intent data2 =data;
            nombrePic = data.getStringExtra("nombrePic");

            Log.w("okoko", "onActivityResult .......");
            bm = showAndScale();
            imageFront.setImageBitmap(bm);
        }

        /*
        if (requestCode == 7 && resultCode == RESULT_OK) {
            //Uri selectedImage = this.data.getData();
            bm = showAndScale();
            imageFront.setImageBitmap(bm);

            //String path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS) + "/audits/" + id + "/" + nombrePic;
        }
        */
    }

    private Bitmap showAndScale() {
        File imgFile = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), nombrePic);
        if (imgFile.exists()) {
            bm = BitmapFactory.decodeFile(imgFile.getAbsolutePath());
            nombrePicPrincipal = nombrePic;

            /*  /// se pasa el codigo de guardar en la bd al activiti de camara
            sql = "SELECT pic FROM qa_zeval WHERE id_evaluacion_fb='" + idE + "'";
            cursor = db.rawQuery(sql, null);
            if (cursor.getCount() > 0) {
                while (cursor.moveToNext()) {
                    nombrePicPrincipal = cursor.getString(0);
                    sql = "UPDATE qa_zeval SET pic='" + nombrePic + "' WHERE id_evaluacion_fb='" + idE + "'";
                    db.execSQL(sql);
                }
            }
             */


            /*
            try {
                if (bm != null) {
                    FileOutputStream ostream = new FileOutputStream(imgFile);
                    float rs = (float) 600 / bm.getWidth();
                    bm = Bitmap.createScaledBitmap(bm, (int) ((int) bm.getWidth() * rs), (int) ((int) bm.getHeight() * rs), true);
                    bm.compress(Bitmap.CompressFormat.JPEG, 100, ostream);
                    sql = "SELECT pic FROM qa_zeval WHERE id_evaluacion_fb='" + idE + "'";
                    cursor = db.rawQuery(sql, null);
                    if (cursor.getCount() > 0) {
                        while (cursor.moveToNext()) {
                            nombrePicPrincipal = cursor.getString(0);
                            sql = "UPDATE qa_zeval SET pic='" + nombrePic + "' WHERE id_evaluacion_fb='" + idE + "'";
                            db.execSQL(sql);
                        }
                    }
                    ostream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            */
        }
        return bm;
    }

    private File createImageFile() throws IOException {
        nombrePic = "";
        String imageFileName = "FRONT_";
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",   /* suffix */
                getExternalFilesDir(Environment.DIRECTORY_PICTURES)  /* directory */
        );

        this.nombrePic = image.getName();
        return image;
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_serv_eval_back, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.continuar_evaluacionEF:

                openActivity();

                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void openActivity() {
        Intent intent = new Intent(EvaluacionForm.this, EvaluacionList.class);
        intent.putExtra("id_area", this.id_area);
        intent.putExtra("id_servicio", this.id_servicio);

        ProgressDialog progressBar;
        progressBar = new ProgressDialog(EvaluacionForm.this, R.style.MyAlertDialogStyle);
//        progressDialog.setIndeterminate(true);
//        progressDialog.isShowing();
//
//        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
//        progressDialog.setCancelable(false);
//        progressDialog.setMessage("Actualizando...");
//        progressDialog.setTitle("Espere");
//        progressDialog.incrementProgressBy(50);
//        progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
//        progressDialog.show();

        progressBar.setCancelable(false);
        progressBar.setTitle("Actualizando");

        progressBar.setMessage("Espere...");
        progressBar.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressBar.setProgress(0);
        progressBar.setMax(100);
        progressBar.show();



        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                progressBar.incrementProgressBy(50);
                progressBar.dismiss();
                Toast.makeText(EvaluacionForm.this, "Los datos se han guardado con éxito!", Toast.LENGTH_SHORT).show();
                startActivity(intent);
                finish();
            }
        }, 5000);


    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == event.KEYCODE_BACK) {

        }
        return false;
    }







    private void enableCamera() {
        Intent intent = new Intent(this, CameraActivity.class);
        intent.putExtra("nombrePic", nombrePic);
        intent.putExtra("tipoFoto", "principal");
        intent.putExtra("idE", idE);
        intent.putExtra("idPregunta", "");
        //startActivity(intent);

        startActivityForResult(intent, 2);
    }

}