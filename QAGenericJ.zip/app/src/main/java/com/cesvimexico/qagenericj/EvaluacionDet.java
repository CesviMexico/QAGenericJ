package com.cesvimexico.qagenericj;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class EvaluacionDet extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_evaluacion_det);
    }
}